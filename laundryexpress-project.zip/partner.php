<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0" />
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <link rel="stylesheet" type="text/css" href="css/site.css">
    <link href="https://fonts.googleapis.com/css?family=Quattrocento+Sans" rel="stylesheet"> 
    <script type="text/javascript" src="js/jquery.js"></script>
    <script type="text/javascript" src="js/jquery_cycle.js"></script>
    <link rel="shortcut icon" href="img/fav.png">
    <title>laundryexpress | keeping you fresh in 24hrs</title>


  </head>
  
  <body>


  <style type="text/css">
      



  </style>




    <div class="backdrop"></div>


          <div class="floater loginFloat Logistics">
                <span>Input your Logistic Details</span>
                <input type="text" class="logicName" placeholder="Company Name" />
                <input type="email" class="logicEmail" placeholder="Company Email" name="" />
                <input type="text" class="logicPerson" placeholder="Company Contact Person" />
                <input type="text" class="logicPhone" placeholder="Copany Contact Number" />
                <input type="text" class="logicAddr" placeholder="Company Address" />
                <sup>We'd get back to you soon after you submit this</sup>
                <button class="loginButton">Submit Info</button>

            </div>



            <div class="floater registerFloat">
                <span>Register your Dry-Cleaning Service</span>
                <input type="text" class="vendorName" placeholder="Dry-Cleaning Service Name" />
                <input type="email" class="vendorEmail" placeholder="Service Email" name="" />
                <input type="text" class="vendorPerson" placeholder="Contact Person" />
                <input type="text" class="vendorPhone" placeholder="Contact Number" />
                <input type="text" class="vendorAddr" placeholder="Address" />
                <sup>We'd get back to you soon after you submit this</sup>
                <button class="registerButton">Submit Info</button>

            </div>


 



    <header style="border: 0px solid transparent;">
        <div class="logo">
            <img src="img/logo.png" />
        </div>

        <div class="tel" style="padding-top: 10px; font-size: 17px;"><i class="material-icons">call</i> 0809 782 0000  &emsp;  <span class="getIn">Login</span> &emsp; <span class="ship">Get Started</span> &emsp; <span>Partner</span></div>

       
    </header>



    <section>




        <div class="signed">
            <div class="logic">
               <i class="material-icons">local_shipping</i>
               <div class="pulse">Logistics Partnership</div>
            </div>

            <div class="vendor">
               <i class="material-icons">store</i>
               <div class="pulse">Vendor Partnership</div>
            </div>
        </div>


  		


         <div class="footer">
            <div class="col3">
                <div class="pin"><a href="about">About Us</a></div>
                <div class="pack"><a href="faq">FAQ</a></div>
                <div class="pack"><a href="terms">Terms</a></div>
                <div class="pack"><a href="privacy">Privacy Policy</a></div>            
            </div>


            <div class="col3">
                <div class="pin">Work with Us</div>
                <div class="pack"><a href="partner">Become a partner</a></div>
            </div>

            <div class="col3">
                <div class="pin">Contact Us</div>
                <div class="pack">info@laundryexpress.ng</div>
                <div class="pack">0809 782 0000</div>
                <div class="pack">7, Thorburn Avenue, Sabo, Yaba, Lagos</div>
            </div>

            <div class="col3">
                <div class="pin">Connect with Us</div>
                <div class="pack">Facebook</div>
                <div class="pack">Twitter</div>
                <div class="pack">Instagram</div>
            </div>
         </div>
         <div class="footer" style="padding: 15px; text-align: center;">laundryexpress &copy;2017. All Rights Reserved.</div>



         
      	 
      	 
      </section>

      		

      <style type="text/css">

          
          .signed {
             float: left;
             width: 100%;
             padding: 10%;
             box-sizing: border-box;
          }
          .logic, .vendor {
             float: left;
             width: 50%;
             padding: 10%;
             box-sizing: border-box;
             cursor: pointer;
          }
          .logic {
             border-right: 3px solid #ddd;
          }
          .logic i, .vendor i {
             float: left;
             width: 100%;
             text-align: center;
             font-size: 120px;
          }
          .pulse {
             float: left;
             width: 100%;
             margin-top: 70px;
             text-align: center;
             font-size: 25px;
             font-weight: bold;
          }

      </style>
      
      


      <script type="text/javascript">
      	  $(document).ready(function() {

      	  		$('.vendor').click(function() {
      	  			$('.backdrop, .registerFloat').show();
      	  			$('.loginFloat').hide();

      	  		});

      	  		$('.logic').click(function() {
      	  			$('.backdrop, .loginFloat').show();
      	  			$('.registerFloat').hide();
      	  		});

      	  		$('.backdrop').click(function() {
      	  			$('.backdrop, .floater').hide();
      	  		});




          $("#slideImage").cycle({
              fx:"fade",
              delay:0000,
              timeout:5000,
          }); 


           $('.userBtn').click(function() {
                 $('.menuSlate').toggleClass("hidd");
              });

           $('.menuSlate').click(function() {
               $('.menuSlate').toggleClass("hidd");
           })
       


      	  });
      </script>



      <script src="https://www.gstatic.com/firebasejs/4.1.3/firebase.js"></script>
      <script>
        // Initialize Firebase
        var config = {
          apiKey: "AIzaSyClWW_biehboxnAUbXeEUwVq7Rux_kxdyo",
          authDomain: "laundryexpress-816979.firebaseapp.com",
          databaseURL: "https://laundryexpress-816979.firebaseio.com",
          projectId: "laundryexpress-816979",
          storageBucket: "laundryexpress-816979.appspot.com",
          messagingSenderId: "400733907548"
        };
        firebase.initializeApp(config);
      </script>

    
      <script type="text/javascript" src="js/partner.js"></script>
  </body>
</html>
