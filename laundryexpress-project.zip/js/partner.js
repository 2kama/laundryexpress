$(document).ready(function() {

		const auth = firebase.auth();
		const db = firebase.database();

		auth.onAuthStateChanged(function(user) {
		  if (user) {

		  		setTimeout("location.href = 'home';",0000);

		  } else {
		    



		  		//Register the user


		  		$('.registerButton').click(function() {

		  			var logicName = $('.vendorName').val();
		  			var logicEmail = $('.vendorEmail').val();
		  			var logicPerson = $('.vendorPerson').val();
		  			var logicPhone = $('.vendorPhone').val();
		  			var logicAddr = $('.vendorAddr').val();

		  			var dateTime = new Date().getTime();

		  			var logicPath = Math.random().toString(36).substr(2, 7);
		  			var timestamp = Math.floor(dateTime / 1000);

		  			$('.registerButton').html("Submitting.....");




		  			db.ref().child('vendor/' + logicPath).set({
		  				dateReg: timestamp,
		  				name: logicName,
		  				email: logicEmail,
		  				person: logicPerson,
		  				phone: logicPhone,
		  				addr: logicAddr,
		  				approved: false
		  			}).then(function() {

		  					$('.registerButton').html("Submit Info");

		  					$('.vendorName, .vendorEmail, .vendorPerson, .vendorAddr, .vendorPhone').val("");


		  					setTimeout(function(){
		  							$('.registerFloat, .backdrop').hide();

		  					}, 3000);

		  					


		  			});



				

		  		});




		  		$('.loginButton').click(function() {

		  			var logicName = $('.logicName').val();
		  			var logicEmail = $('.logicEmail').val();
		  			var logicPerson = $('.logicPerson').val();
		  			var logicPhone = $('.logicPhone').val();
		  			var logicAddr = $('.logicAddr').val();

		  			var dateTime = new Date().getTime();

		  			var logicPath = Math.random().toString(36).substr(2, 7);
		  			var timestamp = Math.floor(dateTime / 1000);

		  			$('.loginButton').html("Submitting.....");




		  			db.ref().child('logistics/' + logicPath).set({
		  				dateReg: timestamp,
		  				name: logicName,
		  				email: logicEmail,
		  				person: logicPerson,
		  				phone: logicPhone,
		  				addr: logicAddr,
		  				approved: false
		  			}).then(function() {

		  					$('.loginButton').html("Submit Info");

		  					$('.logicName, .logicEmail, .logicPerson, .logicPhone, .logicAddr').val("");

		  					setTimeout(function(){
		  							$('.loginFloat, .backdrop').hide();

		  					}, 3000);


		  			});







		  			

				

		  		});






		  		




		  }
		});


});