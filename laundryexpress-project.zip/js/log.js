$(document).ready(function(){




		const auth = firebase.auth();
		const db = firebase.database();

		auth.onAuthStateChanged(function(user) {
		  if (user) {
		    	var uid = auth.currentUser.uid;
		    	var thisemail = auth.currentUser.email;



		    	
		    	$('.lo').click(function() {

		    		auth.signOut();

		    	});



		    	db.ref().child('users/' + uid).update({
		    		email: thisemail
		    	});

		    	db.ref().child('users/' + uid).on("value", snapshot => {

		    			var username = snapshot.val().name;
		    			var usermail = snapshot.val().email;
		    			var usertel	= snapshot.val().tel;
		    			var usertype = snapshot.val().type;
		    			var useraddr = snapshot.val().address;

                        if(usertype == "normal") {

                        }
                        else if(usertype == "logistics") {
                            
                        }
                        else if(usertype == "vendor") {

                        }
                        else {

                        }




                        if(useraddr == "" || useraddr == undefined || username == "" || username == undefined || usertel == "" || usertel == undefined) {
                  			setTimeout("location.href = 'profile';",0000);
		    			}
		    			else {

		    				
                            $('.userName').html(username);
		    			}

                        
		    	});




		    	db.ref().child('orders').orderByChild('orderTime').on('child_added', snapshot => {

		    			var keys = snapshot.key;
		    			var orderID = keys;
		    			var customer = snapshot.val().customer;
		    			var uid = auth.currentUser.uid;

		    			if(customer != uid) {

		    			}
		    			else {



		    			$('.close').prepend("<div class='close1 " + keys + "'></div>");

		    			$('.' + keys).append("<div class='full'>" + orderID + "  (Track your order with this ID)</div>");

		    			var laundryPlanType = snapshot.val().laundryPlanType;
						var laundrySuitsNum = snapshot.val().laundrySuitsNum;
						var laundryBedsheetsNum = snapshot.val().laundryBedsheetsNum;
						var laundryCurtainsNum = snapshot.val().laundryCurtainsNum;
						var laundryAgbadaNum = snapshot.val().laundryAgbadaNum;
						var laundryDuvetNum = snapshot.val().laundryDuvetNum;
						var pickTime = snapshot.val().pickTime;
						var deliveredTime = snapshot.val().deliveredTime;

						if (pickTime == 0) {
							var picking = "Not picked yet";
						}
						else {
							var picking = pickTime;
						}

						

							if(deliveredTime == 0) {
								var deliver = "Not delivered yet"; 
							}
							else {
								var deliver = deliveredTime
							}


						if(laundryPlanType != "none") {
							var laundryPlan = snapshot.val().laundryPlan;
							var laundryPieces = snapshot.val().laundryPieces;
							var planPrice = snapshot.val().planPrice;

							

							if(laundryPlan == "Monthly Plan") {
								$('.' + keys).append("<div class='orderB'><div class='anA'>" + laundryPlanType + " " + laundryPlan + "</div> <div class='anB'>&#8358; " + planPrice + "</div> <div class='anB'>" + picking + "</div> <div class='anB'>" + deliver +  "</div></div>");
							}
							else if(laundryPlan == "Weekly Plan") {
								$('.' + keys).append("<div class='orderB'><div class='anA'>" + laundryPlanType + " " + laundryPlan + "</div> <div class='anB'>&#8358; " + planPrice + "</div> <div class='anB'>" + picking + "</div> <div class='anB'>" + deliver +  "</div></div>");
							}
							else {
								$('.' + keys).append("<div class='orderB'><div class='anA'>" + laundryPlanType + " " + laundryPlan + " (" + laundryPieces + " Pieces)</div> <div class='anB'>&#8358; " + planPrice + "</div> <div class='anB'>" + picking + "</div> <div class='anB'>" + deliver +  "</div></div>");
							}

						}

						if(laundrySuitsNum != 0) {
							var laundrySuitsPrice = snapshot.val().laundrySuitsPrice;

							

							$('.' + keys).append("<div class='orderB'><div class='anA'>Suits (" + laundryPlanType + ") [" + laundrySuitsNum + " Pairs]</div> <div class='anB'>&#8358; " + laundrySuitsPrice + "</div> <div class='anB'>" + picking + "</div> <div class='anB'>" + deliver +  "</div></div>");
						}


						if(laundryBedsheetsNum != 0) {
							var laundryBedsheetsPrice = snapshot.val().laundryBedsheetsPrice;

							

							$('.' + keys).append("<div class='orderB'><div class='anA'>Bedsheets (" + laundryPlanType + ") [" + laundryBedsheetsNum + " Sheets]</div> <div class='anB'>&#8358; " + laundryBedsheetsPrice + "</div> <div class='anB'>" + picking + "</div> <div class='anB'>" + deliver +  "</div></div>");
						}


						if(laundryCurtainsNum != 0) {
							var laundryCurtainsPrice = snapshot.val().laundryCurtainsPrice;


							$('.' + keys).append("<div class='orderB'><div class='anA'>Curtains (" + laundryPlanType + ") [" + laundryCurtainsNum + " Sets]</div> <div class='anB'>&#8358; " + laundryCurtainsPrice + "</div> <div class='anB'>" + picking + "</div> <div class='anB'>" + deliver +  "</div></div>");
						}

						if(laundryAgbadaNum != 0) {
							var laundryAgbadaPrice = snapshot.val().laundryAgbadaPrice;

							

							$('.' + keys).append("<div class='orderB'><div class='anA'>Agbada (" + laundryPlanType + ") [" + laundryAgbadaNum + " Sets]</div> <div class='anB'>&#8358; " + laundryAgbadaPrice + "</div> <div class='anB'>" + picking + "</div> <div class='anB'>" + deliver +  "</div></div>");
						}

						if(laundryDuvetNum != 0) {
							var laundryDuvetPrice = snapshot.val().laundryDuvetPrice;

							

							$('.' + keys).append("<div class='orderB'><div class='anA'>Duvet (" + laundryPlanType + ") [" + laundryDuvetNum + " Sets]</div> <div class='anB'>&#8358; " + laundryDuvetPrice + "</div> <div class='anB'>" + picking + "</div> <div class='anB'>" + deliver +  "</div></div>");
						}




					}





				});


		    	

				
		  		

		  } else {
		    
		  			setTimeout("location.href = 'index';",0000);

		  	
		  }
		});



		







});