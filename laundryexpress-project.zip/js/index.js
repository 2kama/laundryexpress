$(document).ready(function() {

		const auth = firebase.auth();
		const db = firebase.database();

		auth.onAuthStateChanged(function(user) {
		  if (user) {

		  		setTimeout("location.href = 'home';",0000);

		  } else {
		    



		  		//Register the user


		  		$('.registerButton').click(function() {

		  			var pass = $('.registerPass').val();
		  			var email = $('.registerEmail').val();

		  			$('.registerButton').html("Registering User...");
		  			$('.registerError').hide();



		  			auth.createUserWithEmailAndPassword(email, pass).catch(function(error) {
					  // Handle Errors here.
					  var errorCode = error.code;
					  var errorMessage = error.message;
						   	
						   	
					  		$('.registerButton').html("Register");
					  		$('.registerError').html(errorMessage).show();

						
					  // ...
					});

				

		  		});




		  		$('.loginButton').click(function() {

		  			var pass = $('.loginPass').val();
		  			var email = $('.loginEmail').val();

		  			$('.loginButton').html("Authenticating User...");
		  			$('.loginError').hide();



		  			auth.signInWithEmailAndPassword(email, pass).catch(function(error) {
					  // Handle Errors here.
					  var errorCode = error.code;
					  var errorMessage = error.message;
						   	
						   	
					  		$('.loginButton').html("Login");
					  		$('.loginError').html(errorMessage).show();

						
					  // ...
					});

				

		  		});






		  		




		  }
		});


});