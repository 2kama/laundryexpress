$(document).ready(function() {

		const auth = firebase.auth();
		const db = firebase.database();

		auth.onAuthStateChanged(function(user) {
		  if (user) {
		    	var uid = auth.currentUser.uid;
		    	localStorage.thisemaillaundryexpress = auth.currentUser.email;


          
          $('.lo').click(function() {

            auth.signOut();

          });



		    	db.ref().child('users/' + uid).update({
		    		email: localStorage.thisemaillaundryexpress
		    	});



          db.ref().child('users').on("value", snaps => {
          if (snaps.hasChild(uid)) {

              db.ref().child('users/' + uid).once("value", snapshot => {

              var username = snapshot.val().name;
              var usermail = snapshot.val().email;
              var usertel = snapshot.val().tel;
              var userpic = snapshot.val().pic;
              var usertype = snapshot.val().type;
              var useraddr = snapshot.val().address;

                        if(usertype == "normal") {

                        }
                        else if(usertype == "logistics") {
                            
                        }
                        else if(usertype == "vendor") {

                        }
                        else {

                        }

                        

              if(useraddr == "" || useraddr == undefined || username == "" || username == undefined || usertel == "" || usertel == undefined) {
                  setTimeout("location.href = 'profile';",0000);
              }
              else {

                $('.searcher').val(useraddr);
                            $('.userName').html(username);
              }
          });

          }
          else {
              db.ref().child('users/' + uid).set({
                  name: "New User",
                  email: localStorage.thisemaillaundryexpress,
                  tel: "",
                  pic: "",
                  type: "normal",
                  address: ""
              });
          }

        });

		    	

		    	

				
		  		

		  } else {
		    
		  			setTimeout("location.href = 'index';",0000);

		  	
		  }
		});



        //workings



         var laundryPlan = "none", laundryPlanType = "none", insure = 0, laundryPrice = 0, laundryPieces = 0, laundryAgbadaNum = 0, laundryAgbadaPrice = 0; 
         var laundryCurtainsNum = 0, laundryCurtainsPrice = 0, laundrySuitsNum = 0, laundrySuitsPrice = 0, laundryDuvetPrice = 0, laundryDuvetNum = 0;
         var laundryBedsheetsNum = 0, laundryBedsheetsPrice = 0, planPrice = 0, insurance = 0;
         



		
         $('#map-canvas').click(function() {
            $('.info').css("background", "#285296");
            $('.info').css("color", "#fff");
            $('.info').css("cursor", "pointer");
            $('.info').html("Next Step");
        });


        $('.info').click(function() {

          $('.backdrop, .session2').show();

        });

        $('.session2 .previous').click(function() {

          $('.backdrop, .session2').hide();

        });

        $('.monthly').click(function() {
          $('.session2').hide();
          $('.monthlyPlan').show();
          laundryPlan = "Monthly Plan";
          laundryPlanType = "none";
          laundryPrice = 0;
          planPrice = 0;
          laundryPieces = 0;
          $('.zero .order').remove();
          $('.session3 .next').hide();
        });
        $('.monthlyPlan .previous').click(function() {
          $('.session3').hide();
          $('.session2').show();
        });

        $('.weekly').click(function() {
          $('.session2').hide();
          $('.weeklyPlan').show();

          laundryPlan = "Weekly Plan";
          laundryPlanType = "none";
          laundryPrice = 0
          planPrice = 0;
          laundryPieces = 0;
          $('.zero .order').remove();
          $('.session3 .next').hide();
        });
        $('.weeklyPlan .previous').click(function() {
          $('.session3').hide();
          $('.session2').show();
        });

        $('.oneoff').click(function() {
          $('.session2').hide();
          $('.oneOff').show();
          laundryPlan = "One-Off Plan";
          laundryPlanType = "none";
          laundryPrice = 0;
          planPrice = 0;
          $('.zero .order').remove();
          $('.session3 .next').hide();
        });
        $('.oneOff .previous').click(function() {
          $('.session3').hide();
          $('.session2').show();
        });

        $('.monthlyPlan .next, .weeklyPlan .next, .oneOff .next').click(function() {
        	$('.session3').hide();
        	$('.session3_5').show();
        });

        $('.session3_5 .next').click(function() {
            $('.session3_5').hide();
            $('.session4').show();

            if(laundryPlanType == "VIP") {
               $('.onetwo, .session4 .next').show();
               $('.two, .three').hide();
               $('.insure').val("0");
            }
            else {
               $('.onetwo, .session4 .next').hide();
               $('.three').show();
            }
        });
        $('.session3_5 .previous').click(function() {
            $('.session3_5').hide();
            $('.session2').show();

            laundrySuitsPrice = 0;
            laundrySuitsNum = 0;
            laundryAgbadaPrice = 0;
            laundryAgbadaNum = 0;
            laundryCurtainsPrice = 0;
            laundryCurtainsNum = 0;
            laundryBedsheetsPrice = 0;
            laundryBedsheetsNum = 0;
            laundryDuvetPrice = 0;
            laundryDuvetNum = 0;
            $('.number input').val("0");
            $('.specialChoose .price').html("&#8358;0");
        });

       

        $('.yes').click(function() {
        	$('.three').hide();
        	$('.two').show();
        });

        $('.session4 .previous').click(function() {
        	$('.session4').hide();
        	$('.session2').show();
        });

        $('.session5 .previous').click(function() {
        	$('.session5').hide();
        	$('.session4').show();
          laundryPrice = 0;
        });

        $('.previous').click(function() {
            $('.zero').html("");
        });





        

        $('.planChoice').click(function() {
            $('.planChoice').css("background", "#ddd");
            $('.planChoice').css("color", "#444");
            $('.planChoice .highlight i').hide();
            $(this).css("background", "#285296");
            $(this).css("color", "#fff");
            $('.highlight i', this).show();
        });


        //month plans / weekly plans / one-off plans

        $('.monthlyBasic, .weeklyBasic, .basicOne').click(function() {
          laundryPlanType = "Basic";
          $('.session3 .next').show();
        });
        $('.monthlyVip, .weeklyVip, .vipOne').click(function() {
          laundryPlanType = "VIP";
          $('.session3 .next').show();
        });

        

        $('.oneOff .next').click(function() {
          if(laundryPlanType == "Basic") {
            var number = $('.basicOne input').val();
            

            laundryPieces = number;
          }
          else {
             var number = $('.vipOne input').val();
            

            laundryPieces = number;
          }
        });





        // agbada

        $('.agbada .number input').change(function() {
            var new_num = $(this).val();

            if(laundryPlanType == "Basic") {
                var price = 1500;
            }
            else {
                var price = 3000;
            }

            $('.agbada .price').html("&#8358;" + (new_num * price));

            laundryAgbadaNum = new_num;
            laundryAgbadaPrice = new_num * price;
        });



        //suits
        
        $('.suits .number input').change(function() {
            var new_num = $(this).val();

            if(laundryPlanType == "Basic") {
                var price = 1500;
            }
            else {
                var price = 3000;
            }

            $('.suits .price').html("&#8358;" + (new_num * price));

            laundrySuitsNum = new_num;
            laundrySuitsPrice = new_num * price;
        });





        //duvet
        

        $('.duvet .number input').change(function() {
            var new_num = $(this).val();

            if(laundryPlanType == "Basic") {
                var price = 1500;
            }
            else {
                var price = 3000;
            }

            $('.duvet .price').html("&#8358;" + (new_num * price));

            laundryDuvetNum = new_num;
            laundryDuvetPrice = new_num * price;
        });




         //bedsheets
        

        $('.bedsheets .number input').change(function() {
            var new_num = $(this).val();

            if(laundryPlanType == "Basic") {
                var price = 1500;
            }
            else {
                var price = 3000;
            }

            $('.bedsheets .price').html("&#8358;" + (new_num * price));

            laundryBedsheetsNum = new_num;
            laundryBedsheetsPrice = new_num * price;
        });




        //curtains
        

        $('.curtains .number input').change(function() {
            var new_num = $(this).val();

            if(laundryPlanType == "Basic") {
                var price = 1500;
            }
            else {
                var price = 3000;
            }

            $('.curtains .price').html("&#8358;" + (new_num * price));

            laundryCurtainsNum = new_num;
            laundryCurtainsPrice = new_num * price;
        });





        $('.basicOne input').change(function() {

          var new_num = $(this).val();

            var price = 500;


            $('.basicOne .price').html("&#8358;" + (new_num * price));

        });


        




        $('.vipOne input').click(function() {

          var new_num = $(this).val();

            var price = 1000;


            $('.vipOne .price').html("&#8358;" + (new_num * price));

        });


        


        $('.no, .goon, .session4 .next').click(function() {
              insure = $('.insure').val();
              insurance = insure * 0.1;

              $('.finishButton').show();

              $('.session4').hide();
              $('.session5').show();


              if(insure == 0) {
                  if(laundryPlanType == "VIP") {
                     $('.zero').prepend("<div class='order'><span class='orderType'>Insurance Fee</span> <span class='orderPrice'>FREE</span></div>");
                  }
                  else {

                  }
              }
              else {
                 laundryPrice = laundryPrice + insurance;
                 $('.zero').prepend("<div class='order'><span class='orderType'>Insurance Fee</span> <span class='orderPrice'>&#8358;" + insurance + "</span></div>");
              }




              if(laundrySuitsNum != 0) {
                  laundryPrice = laundryPrice + laundrySuitsPrice;

                  if(laundryPlanType == "Basic") {
                      $('.zero').prepend("<div class='order'><span class='orderType'>Suits(Basic) -" + laundrySuitsNum + " Pairs</span> <span class='orderPrice'>&#8358;" + laundrySuitsPrice + "</span></div>");
                  }
                  else {
                    $('.zero').prepend("<div class='order'><span class='orderType'>Suits(VIP) -" + laundrySuitsNum + " Pairs</span> <span class='orderPrice'>&#8358;" + laundrySuitsPrice + "</span></div>");
                  }
             }
             else { }



              if(laundryBedsheetsNum != 0) {
                  laundryPrice = laundryPrice + laundryBedsheetsPrice;

                  if(laundryPlanType == "Basic") {
                      $('.zero').prepend("<div class='order'><span class='orderType'>Bedsheets(Basic) -" + laundryBedsheetsNum + " Sheets</span> <span class='orderPrice'>&#8358;" + laundryBedsheetsPrice + "</span></div>");
                  }
                  else {
                    $('.zero').prepend("<div class='order'><span class='orderType'>Bedsheets(VIP) -" + laundryBedsheetsNum + " Sheets</span> <span class='orderPrice'>&#8358;" + laundryBedsheetsPrice + "</span></div>");
                  }
             }
             else { }


              if(laundryCurtainsNum != 0) {
                  laundryPrice = laundryPrice + laundryCurtainsPrice;

                  if(laundryPlanType == "Basic") {
                      $('.zero').prepend("<div class='order'><span class='orderType'>Curtains(Basic) -" + laundryCurtainsNum + " Sets</span> <span class='orderPrice'>&#8358;" + laundryCurtainsPrice + "</span></div>");
                  }
                  else {
                    $('.zero').prepend("<div class='order'><span class='orderType'>Curtains(VIP) -" + laundryCurtainsNum + " Sets</span> <span class='orderPrice'>&#8358;" + laundryCurtainsPrice + "</span></div>");
                  }
             }
             else { }


              if(laundryAgbadaNum != 0) {
                  laundryPrice = laundryPrice + laundryAgbadaPrice;

                  if(laundryPlanType == "Basic") {
                      $('.zero').prepend("<div class='order'><span class='orderType'>Agbada(Basic) -" + laundryAgbadaNum + " Sets</span> <span class='orderPrice'>&#8358;" + laundryAgbadaPrice + "</span></div>");
                  }
                  else {
                    $('.zero').prepend("<div class='order'><span class='orderType'>Agbada(VIP) -" + laundryAgbadaNum + " Sets</span> <span class='orderPrice'>&#8358;" + laundryAgbadaPrice + "</span></div>");
                  }
             }
             else { }


              if(laundryDuvetNum != 0) {
                  laundryPrice = laundryPrice + laundryDuvetPrice;

                  if(laundryPlanType == "Basic") {
                      $('.zero').prepend("<div class='order'><span class='orderType'>Duvet(Basic) -" + laundryDuvetNum + " Sets</span> <span class='orderPrice'>&#8358;" + laundryDuvetPrice + "</span></div>");
                  }
                  else {
                    $('.zero').prepend("<div class='order'><span class='orderType'>Duvet(VIP) -" + laundryDuvetNum + " Sets</span> <span class='orderPrice'>&#8358;" + laundryDuvetPrice + "</span></div>");
                  }
             }
             else { }




             if(laundryPlan == "Monthly Plan") {
                
                 
                  if(laundryPlanType == "Basic") {
                      planPrice = 12000;
                      laundryPrice = laundryPrice + planPrice;
                      $('.zero').prepend("<div class='order'><span class='orderType'>" + laundryPlan + "(" + laundryPlanType + ")</span> <span class='orderPrice'>&#8358;" + planPrice + "</span></div>");
                  }
                  else if(laundryPlanType == "VIP") {
                      planPrice = 25000;
                      laundryPrice = laundryPrice + planPrice;
                      $('.zero').prepend("<div class='order'><span class='orderType'>" + laundryPlan + "(" + laundryPlanType + ")</span> <span class='orderPrice'>&#8358;" + planPrice + "</span></div>");
                  }
                  else {

                  }

             }




             else if(laundryPlan == "Weekly Plan") {
                  
                  if(laundryPlanType == "Basic") {
                      planPrice = 4000;
                      laundryPrice = laundryPrice + planPrice;
                      $('.zero').prepend("<div class='order'><span class='orderType'>" + laundryPlan + "(" + laundryPlanType + ")</span> <span class='orderPrice'>&#8358;" + planPrice + "</span></div>");
                  }
                  else if(laundryPlanType == "VIP") {
                      planPrice = 8000;
                      laundryPrice = laundryPrice + planPrice;
                      $('.zero').prepend("<div class='order'><span class='orderType'>" + laundryPlan + "(" + laundryPlanType + ")</span> <span class='orderPrice'>&#8358;" + planPrice + "</span></div>");
                  }
                  else {

                  }

             }




             else {
                
                  if(laundryPlanType == "Basic") {
                      planPrice = laundryPieces * 500;
                      laundryPrice = laundryPrice + planPrice + 1000;

                      if(planPrice != 0) {
                          $('.zero').prepend("<div class='order'><span class='orderType'>Logistics Fee</span> <span class='orderPrice'>&#8358;1000</span></div>");
                          $('.zero').prepend("<div class='order'><span class='orderType'>" + laundryPlan + "(" + laundryPlanType + ") -" + laundryPieces + " Pieces</span> <span class='orderPrice'>&#8358;" + planPrice + "</span></div>");
                      }
                      else {
                        $('.zero').prepend("<div class='order'><span class='orderType'>Logistics Fee</span> <span class='orderPrice'>&#8358;1000</span></div>");
                       }
                  }
                  else if(laundryPlanType == "VIP") {
                      planPrice = laundryPieces * 1000;
                      laundryPrice = laundryPrice + planPrice + 1000;
                      if(planPrice != 0) {
                            $('.zero').prepend("<div class='order'><span class='orderType'>Logistics Fee</span> <span class='orderPrice'>&#8358;1000</span></div>");
                          $('.zero').prepend("<div class='order'><span class='orderType'>" + laundryPlan + "(" + laundryPlanType + ") -" + laundryPieces + " Pieces</span> <span class='orderPrice'>&#8358;" + planPrice + "</span></div>");
                      }  
                      else {
                         $('.zero').prepend("<div class='order'><span class='orderType'>Logistics Fee</span> <span class='orderPrice'>&#8358;1000</span></div>");
                      }    
                 }
                  else {

                  }

             }

             var options = "<option value=''>Pick your Address Region</option>" + 
                            "<option value='Akoka'>Akoka</option>" +
                             "<option value='Yaba'>Yaba</option>" +
                             "<option value='Ketu'>Ketu</option>" +
                             "<option value='Apapa'>Apapa</option>" +
                             "<option value='Lekki'>Lekki</option>" +
                             "<option value='Lagos Island'>Lagos Island</option>" +
                             "<option value='Lagos MainLand'>Lagos MainLand</option>" +
                             "<option value='Epe'>Epe</option>" +
                             "<option value='Oshodi'>Oshodi</option>" +
                             "<option value='Mushin'>Mushin</option>" +
                             "<option value='Agege'>Agege</option>" +
                             "<option value='Badagry'>Badagry</option>" +
                             "<option value='Surulere'>Surulere</option>" +
                             "<option value='Ifako'>Ifako</option>" +
                             "<option value='Shomolu'>Shomolu</option>" +
                             "<option value='Ikeja'>Ikeja</option>" +
                             "<option value='Alimosho'>Alimosho</option>" +

                              "<option value='Sabo'>Sabo</option>";


             if(laundryPrice == 0) {
                  $('.zero').html("<div class='order'><span class='orderType'>Your have nothing in your Basket. You can go back and choose a plan.</span></div>");
             }
             else {
                 $('.zero').append("<div class='order'><span class='orderPrice' style='float:left;text-align:left;'>Pickup Address</span><span class='orderType' style='float:right;'><input type='text' name='' class='thisAddress' style='text-align:right;border-radius:0%;-webkit-border-radius:0%;width:80%;float:right;font-size:17px;font-weight:normal;box-sizing:border-box;padding-right:20px;border:2px solid #285296;' /></span></div>");
                 $('.zero').append("<div class='order'><span class='orderPrice' style='float:left;text-align:left;'>Pickup Region</span><span class='orderType' style='float:right;'><select class='geoArea'>" + options + "</select></span></div>");
                 $('.zero').append("<div class='order'><span class='orderType'>TOTAL</span> <span class='orderPrice'>&#8358;" + laundryPrice + "</span></div>");
                 $('.thisAddress').val($('.searcher').val());
             }





             $('.finishButton').click(function() {

                  

                  var uid = auth.currentUser.uid;
                  var addr = $('.thisAddress').val();
                  var pos = localStorage.laundryPos

                  var dateTime = new Date().getTime();
                  var timestamp = Math.floor(dateTime / 1000);


                  var orderIDscan = Math.random().toString(36).substr(2, 7);
                  var orderID = orderIDscan + "-" + timestamp;
                  var geoArea = $('.geoArea').val();



                  if(geoArea != "") {


                          $('.finishButton').html("VERYING...");

                           PaystackPop.setup({
                         key: 'pk_test_e430bd4449111c6332697d0c8f19b509256e27a5',
                         email: localStorage.thisemaillaundryexpress,
                         amount: laundryPrice * 100,
                         container: 'paystackEmbedContainer',
                         callback: function(response){
                          
                              db.ref().child('orders/' + orderID).set({
                                 insurance: insurance,
                                 laundrySuitsPrice: laundrySuitsPrice,
                                 laundrySuitsNum: laundrySuitsNum,
                                 laundryAgbadaPrice: laundryAgbadaPrice,
                                 laundryAgbadaNum: laundryAgbadaNum,
                                 laundryCurtainsPrice: laundryCurtainsPrice,
                                 laundryCurtainsNum: laundryCurtainsNum,
                                 laundryBedsheetsPrice: laundryBedsheetsPrice,
                                 laundryBedsheetsNum: laundryBedsheetsNum,
                                 laundryDuvetPrice: laundryDuvetPrice,
                                 laundryDuvetNum: laundryDuvetNum,
                                 laundryPlan: laundryPlan,
                                 laundryPlanType: laundryPlanType,
                                 laundryPieces: laundryPieces,
                                 planPrice: planPrice,
                                 addr: addr,
                                 pos: pos,
                                 customer: uid,
                                 laundryPrice: laundryPrice,
                                 orderTime: moment().format("MMM Do YY, h:mm: a"),
                                 attendedTo: false,
                                 pickTime: 0,
                                 dropTime: 0,
                                 vendorID: "none",
                                 doneTime: 0,
                                 returnTime: 0,
                                 deliveredTime: 0,
                                 pickedBy: "",
                                 geoArea: geoArea,
                                 tnx_id: response.reference

             
                             }); 

                              $('.finishButton').html("SEND ORDER").hide();


                              setTimeout("location.href = 'log';",5000);




                          },
                        });
                        

  

                  }

                  else {

                       $('.finishButton').html("SEND ORDER");
                  }


                  

             });







        });









});