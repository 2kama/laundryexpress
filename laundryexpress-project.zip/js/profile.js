$(document).ready(function() {

		const auth = firebase.auth();
		const db = firebase.database();

		firebase.auth().onAuthStateChanged(function(user) {
		  if (user) {
		    	var uid = auth.currentUser.uid;



		    	$('.lo').click(function() {

		    		auth.signOut();

		    	});



		    	db.ref().child('users/' + uid).once("value", snapshot => {

		    			var username = snapshot.val().name;
		    			var usermail = snapshot.val().email;
		    			var usertel	= snapshot.val().tel;
		    			var userpic = snapshot.val().pic;
		    			var usertype = snapshot.val().type;
		    			var useraddr = snapshot.val().address;

                        if(usertype == "normal") {

                        }
                        else if(usertype == "logistics") {
                            
                        }
                        else if(usertype == "vendor") {

                        }
                        else {

                        }

                        

		    			if(useraddr == "" || useraddr == undefined || username == "" || username == undefined || usertel == "" || usertel == undefined) {
                 
		    			}
		    			else {

		    				
                            $('.userName').html(username);
		    			}
		    	});





		    	db.ref().child('users/' + uid).on("child_changed", snap => {

		    			$('.registerError').html("Your Profile details has been updated.").show();

		    	});


		    	db.ref().child('users/' + uid).once("value", snaps => {

		    			$('.registerName').val(snaps.val().name);
		    			$('.registerAddress').val(snaps.val().address);
		    			$('.registerTel').val(snaps.val().tel);

		    	});

		    	
		    	$('.updateUser').click(function() {

		    		var myname = $('.registerName').val();
		    		var addr = $('.registerAddress').val();
		    		var mytel = $('.registerTel').val();

		    		$('.registerError').hide();

		    		$('.registerButton').html("Updating Details...");


		    		db.ref().child('users/' + uid).update({

		    			name: myname,
		    			address: addr,
		    			tel : mytel,
		    			type: "normal"

		    		});

		    	});
				
		  		

		  } else {
		    
		  			setTimeout("location.href = 'index';",0000);

		  	
		  }
		});


});