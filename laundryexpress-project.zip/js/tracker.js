$(document).ready(function() {

		const auth = firebase.auth();
		const db = firebase.database();

		firebase.auth().onAuthStateChanged(function(user) {
		  if (user) {
		    	var uid = auth.currentUser.uid;



		    	
		    	$('.lo').click(function() {

		    		auth.signOut();

		    	});




		    	db.ref().child('users/' + uid).once("value", snapshot => {

		    			var username = snapshot.val().name;
		    			var usermail = snapshot.val().email;
		    			var usertel	= snapshot.val().tel;
		    			var userpic = snapshot.val().pic;
		    			var usertype = snapshot.val().type;
		    			var useraddr = snapshot.val().address;

                        if(usertype == "normal") {

                        }
                        else if(usertype == "logistics") {
                            
                        }
                        else if(usertype == "vendor") {

                        }
                        else {

                        }

                        

		    			if(useraddr == "" || useraddr == undefined || username == "" || username == undefined || usertel == "" || usertel == undefined) {
                 
		    			}
		    			else {

		    				
                            $('.userName').html(username);
		    			}
		    	});





		    	
		    	$('.track').click(function() {

		    		var orderID = $('.orderID').val();

		    		$('.registerError').hide();

		    		$('.track').html("Tracking...");
		    		$('.record').css("width", "0%");
                    $('.notice').html("");


		    		db.ref().child('orders').once("value", snaps => {
			 	 		if (snaps.hasChild(orderID)) {

			 	 				db.ref().child('orders/' + orderID).once("value", sna => {
			 	 				
                       				  var pickTime = sna.val().pickTime;
                       				  var dropTime = sna.val().dropTime;
                       				  var doneTime = sna.val().doneTime;
                       				  var returnTime = sna.val().returnTime;
                       				  var deliveredTime = sna.val().deliveredTime;


                       				  if(deliveredTime != 0) {
                       				  	  $('.record').css("width", "100%");
                       				  	  $('.notice').html("Your laundry has been delivered!");
                       				  }
                       				  else if(returnTime != 0) {
                       				  	  $('.record').css("width", "80%");
                       				  	  $('.notice').html("Your laundry is on it\'s way back to you!");
                       				  }
                       				  else if(doneTime != 0) {
                       				  	  $('.record').css("width", "60%");
                       				  	  $('.notice').html("Your laundry has been washed and would soon be delivered to you!");
                       				  }
                       				  else if(dropTime != 0) {
                       				  	  $('.record').css("width", "40%");
                       				  	  $('.notice').html("Your laundry is at the dry-cleaners!");
                       				  }
                       				  else if(pickTime != 0) {
                       				  	  $('.record').css("width", "100%");
                       				  	  $('.notice').html("Your laundry is on it\'s way to the dry-cleaners!");
                       				  }
                       				  else {
                       				  	  $('.record').css("width", "0%");
                       				  	  $('.notice').html("Logistics is on it\'s way to pick your order up!");
                       				  }
			 	 				});
			 	 		}
			 	 		else {
			 	 			$('.registerError').show().html("This OrderID doesn't exist!");
			 	 		}

			 	 		$('.track').html("Track");

			 	 	});

		    	});
				
		  		

		  } else {
		    
		  			setTimeout("location.href = 'index';",0000);

		  	
		  }
		});


});