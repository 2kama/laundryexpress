<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0" />
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <link href="https://fonts.googleapis.com/css?family=Quattrocento+Sans" rel="stylesheet"> 
    <script type="text/javascript" src="js/jquery.js"></script>
    <script type="text/javascript" src="js/moment.js"></script>

    <script src="https://js.paystack.co/v1/inline.js"></script>
    <link rel="shortcut icon" href="img/fav.png">

    <title>Home | laundryexpress</title>
     
  </head>
  
  <body style="overflow: hidden;">



  		<div class="backdrop"></div>

          <div class="b_backdrop"></div>
          <div class="floater loginFloat sipFloat">
                <span>Update your Profile Details</span>

                <a href="profile"><button class="loginButton">Update Details</button></a>

          </div>


          <div class="menuSlate hidd">
             <ul>
                <a href="profile"><li><i class="material-icons">account_circle</i>Profile</li></a>
                <a href="log"><li><i class="material-icons">list</i>Log</li></a>
                <a href="tracker"><li><i class="material-icons">navigation</i>Track Order</li></a>
                <a href="javascript:;"><li class="lo"><i class="material-icons">exit_to_app</i>Logout</li></a>
             </ul>
          </div>


      <header>
      		<div class="logo"><img src="img/logo.png"></div>

          <div class="userBtn">
             <i class="material-icons thin">account_circle</i> <div class="userName">Loading...</div> <i class="material-icons thinner">keyboard_arrow_down</i>
          </div>
      </header>


      <section>
        <div id="map-canvas"></div>

        <div class="search">
           <input type="text" class="searcher" id="searcher" placeholder="pickup location" name="">
        </div>
        <div class="info">SET PICKUP LOCATION</div>






        <div class="session session2">
           <span class="level">STAGE 2 / 5</span>
           <span class="header">CHOOSE A PLAN</span>

           <div class="pack">
               <div class="planChoose monthly">
                  <div class="highlight">MONTHLY PLAN</div>
                  <div class="hint">Got so much laundry for the month? We'd take care of that</div>
               </div>

               <div class="planChoose weekly">
                  <div class="highlight">WEEKLY PLAN</div>
                  <div class="hint">Set a frequent appointment with us... It'd be worth it</div>
               </div>

               <div class="planChoose oneoff">
                  <div class="highlight">ONE OFF PLAN</div>
                  <div class="hint">Just got a little materials flying around?</div>
               </div>
           </div>



            <div class="direction"><div class="previous">PREVIOUS</div></div>

        </div>


        <div class="session session3 monthlyPlan">
            <span class="level">STAGE 3 / 5</span>
            <span class="header">MONTHLY PLAN</span>

            <div class="pack">
                <div class="planChoice monthlyBasic">
                    <div class="highlight">BASIC <i class="material-icons">check</i></div>
                    <div class="hint">max 30 pieces<br>wash, iron, starch<br>pickup & delivery<br>&nbsp;</div>
                    <div class="lowlight">72 hours<br>&#8358;12,000</div>
                </div>

                <div class="planChoice monthlyVip">
                    <div class="highlight">VIP <i class="material-icons">check</i></div>
                    <div class="hint">max 35 pieces<br>wash, iron, starch<br>pickup & delivery<br>phone support system</div>
                    <div class="lowlight">24 hours<br>&#8358;25,000</div>
                </div>
            </div>


            <div class="direction"><div class="previous">PREVIOUS</div><div class="next">NEXT</div></div>

        </div>




        <div class="session session3 weeklyPlan">
            <span class="level">STAGE 3 / 5</span>
            <span class="header">WEEKLY PLAN</span>

            <div class="pack">
                <div class="planChoice weeklyBasic">
                    <div class="highlight">BASIC <i class="material-icons">check</i></div>
                    <div class="hint">max 10 pieces<br>wash, iron, starch<br>pickup & delivery<br>&nbsp;</div>
                    <div class="lowlight">72 hours<br>&#8358;4,000</div>
                </div>

                <div class="planChoice weeklyVip">
                    <div class="highlight">VIP <i class="material-icons">check</i></div>
                    <div class="hint">max 10 pieces<br>wash, iron, starch<br>pickup & delivery<br>phone support system</div>
                    <div class="lowlight">24 hours<br>&#8358;8,000</div>
                </div>
            </div>

           


            <div class="direction"><div class="previous">PREVIOUS</div><div class="next">NEXT</div></div>
        </div>




        <div class="session session3 oneOff">
            <span class="level">STAGE 3 / 5</span>
            <span class="header">ONE OFF (Per Piece Plan)</span>

            <div class="pack">
                <div class="planChoice basicOne">
                    <div class="highlight">BASIC <i class="material-icons">check</i></div>
                    <div class="hint">wash, iron, starch<br>pickup & delivery</div>

                      <div class="panels">
                        <div class="plan"></div>
                        <div class="number">pieces: <input type="number" min="0" value="0" /></div>

                        <div class="price">&#8358;0</div>

                    </div>


                    <div class="lowlight">72 hours<br>&#8358;500 per piece</div>
                </div>

                <div class="planChoice vipOne">
                    <div class="highlight">VIP <i class="material-icons">check</i></div>
                    <div class="hint">wash, iron, starch<br>pickup & delivery</div>

                      <div class="panels">
                        <div class="plan"></div>
                        <div class="number">pieces: <input type="number" min="0" value="0" /></div>

                        <div class="price">&#8358;0</div>

                    </div>

                    <div class="lowlight">24 hours<br>&#8358;1,000 per piece</div>
                </div>
            </div>



            <div class="direction"><div class="previous">PREVIOUS</div><div class="next">NEXT</div></div>
        </div>






         <div class="session session3_5 specials">

            <span class="header">HAVE ANY SPECIAL ORDERS</span>

            <div class="pack">
              
                <div class="specialChoose suits">
                    <div class="panel">
                        <div class="plan">SUITS</div>
                        <div class="number">pairs: <input type="number" min="0" value="0" /></div>

                        <div class="price">&#8358;0</div>

                    </div>
                </div>


                <div class="specialChoose bedsheets">
                    <div class="panel">
                        <div class="plan">BEDSHEETS</div>
                        <div class="number">sets: <input type="number" min="0" value="0" /></div>
                       

                        <div class="price">&#8358;0</div>

                    </div>
                </div>


                <div class="specialChoose curtains">
                    <div class="panel">
                        <div class="plan">CURTAINS</div>
                        <div class="number">sets: <input type="number" min="0" value="0" /></div>
                        

                        <div class="price">&#8358;0</div>

                    </div>
                </div>


                <div class="specialChoose agbada">
                    <div class="panel">
                        <div class="plan">AGBADA</div>
                        <div class="number">sets: <input type="number" min="0" value="0" /></div>
                        

                        <div class="price">&#8358;0</div>

                    </div>
                </div>


                <div class="specialChoose duvet">
                    <div class="panel">
                        <div class="plan">DUVET</div>
                        <div class="number">sets: <input type="number" min="0" value="0" /></div>
                        

                        <div class="price">&#8358;0</div>

                    </div>
                </div>

            </div>  



            <div class="direction"><div class="previous">PREVIOUS</div><div class="next">NEXT</div></div>
        </div>






        <div class="session session4">
          
              <span class="level">STAGE 4 / 5</span>

              <span class="header onetwo" style="font-size: 40px;text-align: center;">No worries! <br> All your clothings are being insured!</span>
            <span class="header three" style="font-size:40px;">Would you like to INSURE?</span>

            <div class="pack three">
              
                  <div class="planChoice">
                      <div class="highlight yes" style="font-size: 60px;">YES</div>
                  </div>


                  <div class="planChoice">
                      <div class="highlight no" style="font-size: 60px;">NO</div>
                  </div>


            </div>  

            <span class="header two" style="font-size: 40px;">Declare value of clothings to insure</span>
            <div class="pack two">
              
                <input type="number" class="insure" name="" value="0" />

                <div class="planChoice">
                    <div class="highlight goon" style="font-size: 60px;">NEXT</div>
                </div>

                <div class="lowlight">
                    
                Insurance = 10% of declared Value<br>
                If you change your mind, just input 0 into the number field.
                </div>

            </div>

            <div class="direction"><div class="previous">PREVIOUS</div><div class="next">NEXT</div></div>
        </div>



        <div class="session session5">
              
              <span class="level">STAGE 5 / 5</span>
              <span class="header">CONFIRM ORDER</span>

              <div class="zero">
                
                  

                  

                  
              </div>  

               <div class="finishButton">SEND ORDER</div>

               <div id="paystackEmbedContainer"></div>

              <div class="direction"><div class="previous">PREVIOUS</div></div>


        </div>





      </section>

      		
      <style type="text/css">
          

      </style>




      <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAoASfJBNlCTNgdL7pVNpuhJHVCFEyeD3o&callback=initMap" async defer></script>
      <script type="text/javascript">
        
          function initMap() {
            var myOptions = {
                zoom: 16,
                center: new google.maps.LatLng(6.5210245325310385, 3.3738327026367188)
              },
              map = new google.maps.Map(document.getElementById('map-canvas'), myOptions),
              marker = new google.maps.Marker({
                map: map,
              }),
              infowindow = new google.maps.InfoWindow;


              var trafficLayer = new google.maps.TrafficLayer();
               trafficLayer.setMap(map);






            map.addListener('click', function(e) {
              //map.setCenter(e.latLng);
              marker.setPosition(e.latLng);
              //infowindow.setContent("Latitude: " + e.latLng.lat() + "<br>" + "Longitude: " + e.latLng.lng());
              infowindow.setContent(document.getElementById('searcher').value);
              infowindow.open(map, marker);
              localStorage.laundryPos = e.latLng;
              localStorage.laundryAddr = document.getElementById('searcher').value;
            });
          }

      </script>


      <script src="https://www.gstatic.com/firebasejs/4.1.3/firebase.js"></script>
      <script>
        // Initialize Firebase
        var config = {
          apiKey: "AIzaSyClWW_biehboxnAUbXeEUwVq7Rux_kxdyo",
          authDomain: "laundryexpress-816979.firebaseapp.com",
          databaseURL: "https://laundryexpress-816979.firebaseio.com",
          projectId: "laundryexpress-816979",
          storageBucket: "laundryexpress-816979.appspot.com",
          messagingSenderId: "400733907548"
        };
        firebase.initializeApp(config);
      </script>

    
      <script type="text/javascript" src="js/home.js"></script>


      <script type="text/javascript">
      	  $(document).ready(function() {


              $('.userBtn').click(function() {
                 $('.menuSlate').toggleClass("hidd");
              })
       



      	 });
      </script>

  </body>
</html>
