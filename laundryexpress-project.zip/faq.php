<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0" />
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <link rel="stylesheet" type="text/css" href="css/site.css">
    <link href="https://fonts.googleapis.com/css?family=Quattrocento+Sans" rel="stylesheet"> 
    <script type="text/javascript" src="js/jquery.js"></script>
    <script type="text/javascript" src="js/jquery_cycle.js"></script>
    <link rel="shortcut icon" href="img/fav.png">
    <title>laundryexpress | FAQ</title>


  </head>
  
  <body>



   <div class="menuSlate hidd">
             <ul>
                <a href="javascript:;"><li><i class="material-icons">call</i>0809 782 0000</li></a>
                <a href="javascript:;"><li class="getIn"><i class="material-icons">verified_user</i>Login</li></a>
             <a href="partner"><li><i class="material-icons">perm_identity</i>Become a Partner</li></a>
                
                <a href="javascript:;"><li class="ship"><i class="material-icons">check</i>Get Started</li></a>
             </ul>
          </div>



    <header style="border: 0px solid transparent;">
        <div class="logo">
            <img src="img/logo.png" />
        </div>

        <div class="tel" style="padding-top: 10px; font-size: 17px;"><i class="material-icons">call</i> 0809 782 0000  &emsp;  <span class="getIn">Login</span> &emsp; <span class="ship">Get Started</span> &emsp; <span>Partner</span></div>

        <div class="userBtn" style="">
             <i class="material-icons thin">menu</i> 
          </div>
    </header>



  		<div class="backdrop"></div>


      		<div class="floater loginFloat">
                <span>Login</span>
                <input type="email" class="loginEmail" placeholder="Email..." name="" />
                <input type="password" class="loginPass" placeholder="Password..." name="" />
                <sup>I don't have an account</sup>
                <div class="error loginError"></div>
                <button class="loginButton">Login</button>

            </div>



            <div class="floater registerFloat">
                <span>Register</span>
                <!--<input type="text" class="registerName" placeholder="Fullname..." name="">-->
                <input type="email" class="registerEmail" placeholder="Email..." name="" />
                <!--<input type="text" class="registerTel" placeholder="Phone No..." name="">-->
                <input type="password" class="registerPass" placeholder="Password..." name="" />
                <!--<textarea class="registerAddress" placeholder="Residential Address..."></textarea>-->
                <sup>I already have an account</sup>
                <div class="error registerError"></div>
                <button class="registerButton">Register</button>

            </div>




      <section>
      	   <div class="crossLayer" style="text-align: left;">
              <div class="head">Frequently Asked Questions</div> 
              <div class="body">
                    <b>What exactly does LaundryExpress do?</b><br>
                    There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going
              </div>  

              <div class="body">
                    <b>What exactly does LaundryExpress do?</b><br>
                    There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going
              </div>  

              <div class="body">
                    <b>What exactly does LaundryExpress do?</b><br>
                    There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going
              </div>  

              <div class="body">
                    <b>What exactly does LaundryExpress do?</b><br>
                    There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going
              </div>  

              <div class="body">
                    <b>What exactly does LaundryExpress do?</b><br>
                    There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going
              </div>  

              <div class="body">
                    <b>What exactly does LaundryExpress do?</b><br>
                    There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going
              </div>  

              <div class="body">
                    <b>What exactly does LaundryExpress do?</b><br>
                    There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going
              </div>  

              <div class="body">
                    <b>What exactly does LaundryExpress do?</b><br>
                    There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going
              </div>  

              <div class="body">
                    <b>What exactly does LaundryExpress do?</b><br>
                    There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going
              </div>  

              <div class="body">
                    <b>What exactly does LaundryExpress do?</b><br>
                    There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going
              </div>  
           </div>



         <div class="footer">
            <div class="col3">
                <div class="pin"><a href="about">About Us</a></div>
                <div class="pack"><a href="faq">FAQ</a></div>
                <div class="pack"><a href="terms">Terms</a></div>
                <div class="pack"><a href="privacy">Privacy Policy</a></div>
            </div>


            <div class="col3">
                <div class="pin">Work with Us</div>
                <div class="pack"><a href="partner">Become a partner</a></div>
            </div>

            <div class="col3">
                <div class="pin">Contact Us</div>
                <div class="pack">info@laundryexpress.ng</div>
                <div class="pack">0809 782 0000</div>
                <div class="pack">7, Thorburn Avenue, Sabo, Yaba, Lagos</div>
            </div>

            <div class="col3">
                <div class="pin">Connect with Us</div>
                <div class="pack">Facebook</div>
                <div class="pack">Twitter</div>
                <div class="pack">Instagram</div>
            </div>
         </div>
         <div class="footer" style="padding: 15px; text-align: center;">laundryexpress &copy;2017. All Rights Reserved.</div>



         
      	 
      	 
      </section>

      		

      <style type="text/css">

          
         

      </style>
      
      


      <script type="text/javascript">
      	  $(document).ready(function() {

      	  		$('.getStart, .loginFloat sup, .ship').click(function() {
      	  			$('.backdrop, .registerFloat').show();
      	  			$('.loginFloat').hide();

      	  		});

      	  		$('.getIn, .registerFloat sup').click(function() {
      	  			$('.backdrop, .loginFloat').show();
      	  			$('.registerFloat').hide();
      	  		});

      	  		$('.backdrop').click(function() {
      	  			$('.backdrop, .floater').hide();
      	  		});




          $("#slideImage").cycle({
              fx:"fade",
              delay:0000,
              timeout:5000,
          }); 


           $('.userBtn').click(function() {
                 $('.menuSlate').toggleClass("hidd");
              });

           $('.menuSlate').click(function() {
               $('.menuSlate').toggleClass("hidd");
           })
       


      	  });
      </script>



      <script src="https://www.gstatic.com/firebasejs/4.1.3/firebase.js"></script>
      <script>
        // Initialize Firebase
        var config = {
          apiKey: "AIzaSyClWW_biehboxnAUbXeEUwVq7Rux_kxdyo",
          authDomain: "laundryexpress-816979.firebaseapp.com",
          databaseURL: "https://laundryexpress-816979.firebaseio.com",
          projectId: "laundryexpress-816979",
          storageBucket: "laundryexpress-816979.appspot.com",
          messagingSenderId: "400733907548"
        };
        firebase.initializeApp(config);
      </script>

    
      <script type="text/javascript" src="js/index.js"></script>
  </body>
</html>
