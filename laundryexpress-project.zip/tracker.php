<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0" />
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <link href="https://fonts.googleapis.com/css?family=Quattrocento+Sans" rel="stylesheet"> 
    <script type="text/javascript" src="js/jquery.js"></script>
    <link rel="shortcut icon" href="img/fav.png">

    <title>Tracker | laundryexpress</title>


  </head>
  
  <body>



           



      <div class="menuSlate hidd">
             <ul>
                <a href="profile"><li><i class="material-icons">account_circle</i>Profile</li></a>
                <a href="log"><li><i class="material-icons">list</i>Log</li></a>
                <a href="tracker"><li><i class="material-icons">navigation</i>Track Order</li></a>
                <a href="javascript:;"><li class="lo"><i class="material-icons">exit_to_app</i>Logout</li></a>
             </ul>
          </div>


      <header>
          <div class="logo"><img src="img/logo.png"></div>

          <div class="userBtn">
             <i class="material-icons thin">account_circle</i> <div class="userName">Loading...</div> <i class="material-icons thinner">keyboard_arrow_down</i>
          </div>
      </header>




            <div class="floater registerFloat" style="display: block;">
                <span>Track your Laundry</span>
                <input type="text" class="orderID" placeholder="Your Order ID" name="">
                <div class="error registerError"></div>
                <button class="track">Track</button>




                <div class="loader"><div class="record"></div></div>
                <div class="notice"></div>

            </div>





      		


      
      


      <script type="text/javascript">
      	  $(document).ready(function() {

                
              $('.userBtn').click(function() {
                 $('.menuSlate').toggleClass("hidd");
              })
       
      	  });
      </script>



      <script src="https://www.gstatic.com/firebasejs/4.1.3/firebase.js"></script>
      <script>
        // Initialize Firebase
        var config = {
          apiKey: "AIzaSyClWW_biehboxnAUbXeEUwVq7Rux_kxdyo",
          authDomain: "laundryexpress-816979.firebaseapp.com",
          databaseURL: "https://laundryexpress-816979.firebaseio.com",
          projectId: "laundryexpress-816979",
          storageBucket: "laundryexpress-816979.appspot.com",
          messagingSenderId: "400733907548"
        };
        firebase.initializeApp(config);
      </script>

      <script type="text/javascript" src="js/tracker.js"></script>
  </body>
</html>
